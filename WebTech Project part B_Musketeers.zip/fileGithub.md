# Webtech report

GROUP MUSKETEERS
‘ICT4M 2020’


	Prepared by:
TASNIM RAFIA	1725826
MD FERDOUS AHMED KHAN	1825869
SADIA MOMOTAJ ANONNA	1537530
SONIA TABASSUM ANTU	1716978
CHOWDHURY MD ABU SAYED	1711237


	Group contribution:
	In our system, since we have nine pages in total, we divided approximately 2 for each person. Every single person tried hard to prepare the website as perfect as possible.


	Future enhancement:
Name	Contribution	Future enhancement




Ferdous
	•	Pages: Home page,
           Conference program


•	Web element:  slide show,
effect	- Add another few more menus and two more pages to clarify the website in a better way.

- To be responded towards users regarding colour and decoration issue.



        Tabassum

	•	Pages: Conference committee,
           Keynote speeches.
	- To add more URL links so that users might know detail about the committee members more.


Sadia	•	Pages: Contact page,
            Conference fees
•	Web element: google map	- To add a properly usable google map and also to decorate page clearly.




Tasnim	•	Pages: Call for papers & Important Dates,
Submission Guidelines,
Registration page.

•	Web element: addEventListener, button
	- To reduce theoretical items on page, to add more hyperlinks.
- To create a box regarding the important schedule since now simple html is been used to create this one.
- To make the registration page clearer.

Sayed	•	Pages: Previous ICT4M	- To include more incidents.  



	Modification and report:
Team member	Task


Ferdous	•	Modification

•	Combining web pages



Tasnim	•	Writing read me file

•	Combing activities


	Reference:
In order to find some detail and sharing URL we used the previous ICT4M website more like a sample.
http://ict4m.iium.edu.my/

As a helping hand we used w3 school regarding html and css.
https://www.w3schools.com/html/html_css.asp
https://www.w3schools.com/js/default.asp
